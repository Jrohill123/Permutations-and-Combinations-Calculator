#include <iostream>
using namespace std;

class Permutations
{
	int top;
	int bottom;
	int answer;

public:
	void calculation(int, int);
};

