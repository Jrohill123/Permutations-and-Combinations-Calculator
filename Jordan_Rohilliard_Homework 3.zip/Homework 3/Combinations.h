#include <iostream>
using namespace std;

class Combinations
{
	int top, bottom, bottom2;
	int answer;
public:
	void calculation(int, int);
};

